Made by 'Rodrigo López Fernández'
All sprites were made by me

--CONTROLS--
← → ↑ ↓ - Move
Z - Use sword
X - Use arrow (will deplete your arrow count)
enter - restart after you've died
esc - Quit game


--Programer Notes--
This game was made with 'PYGAME' not other versions of it such as pygame zero.

In the 'data' folder there are all the files used for this game.
Feel free to do whatever you want with the code, although I may say that it's pretty messy and janky.
Before you change anything I would make a copy of the game in case you mess something up.


There is a file called 'world_maker' which alows you to create your own maps (you may need python installed in your PC):

Use the mouse wheel to switch blocks and press space to place enemies instead.
Use click to place stuff.
In the code change the variables 'max_x' and 'max_y' to set your world size (number of rooms in both axis).
Use ← → ↑ ↓ to change the room.

After making your map press enter to print your map to the terminal:
	-The world section comes after the ------------------
	-The enemy section comes after the >>>>>>>>>>>>>>>>>>
Press 'esc' to exit.

In the 'load_map' function you can replace the current map with yours:
	-The 'game_map' is where the world section goes
	-The 'enemy_map' is where the enemy section goes

Press backspace to load your map. (If you don't raplace anything you'll load the map used in the game)

After you have created your map in the 'world' file replace the 'test_map' value with yours
	and in the 'enemies' file replace the 'enemy_spawn' value with yours.


HAVE FUN!!!

