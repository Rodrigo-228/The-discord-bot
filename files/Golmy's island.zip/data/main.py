import pygame
import sys

import char
import enemies
import projectile
import collisions
import settings
    
pygame.init()
screen=pygame.display.set_mode((settings.world_size[0]*settings.tile_size,settings.world_size[1]*settings.tile_size+char.char_menu.menu_box[3]),pygame.SCALED|pygame.FULLSCREEN)
fps=pygame.time.Clock()
font=pygame.font.Font('Minecraft_font.otf',10)
bold_font=pygame.font.Font('Minecraft_Bold_font.otf',10)

def draw_char():
    if not char.dead:
        if char.invincibility_frame%8<=3:
            screen.blit(pygame.transform.flip(char.sprite,char.flip,False),char.pos)
        #pygame.draw.rect(screen,(0,255,0),char.hitbox,True)

    pygame.draw.rect(screen,char.char_menu.menu_color,char.char_menu.menu_box)

    for i in range(3):
        screen.blit(char.char_menu.empty_heart,(4+i*18,2))

        if char.health//2-1>=i:
            screen.blit(char.char_menu.full_heart,(4+i*18,2))
        elif char.health/2-0.5==i:
            screen.blit(char.char_menu.half_heart,(4+i*18,2))
    
    screen.blit(font.render('Z',False,(255,255,255)),(66,4))
    screen.blit(font.render('X',False,(255,255,255)),(94,4))
    screen.blit(char.char_menu.sword,(70,0))
    screen.blit(char.char_menu.arrow,(100,2))
    screen.blit(font.render('x'+str(char.arrow_count),False,(255,255,255)),(116,6))

def draw_weapon():
    screen.blit(char.sword,(char.pos[0]+char.sword_pos[0],char.pos[1]+char.sword_pos[1]))
    if char.attack_timer>=8 and char.attack_timer<14:
        screen.blit(char.swipe,(char.pos[0]+char.swipe_pos[0],char.pos[1]+char.swipe_pos[1]))
    #if char.attack_timer>=8 and char.attack_timer<=16:
        #pygame.draw.rect(screen,(0,0,255),char.sword_hitbox)

def draw_arrow():
    for i in projectile.arrow_list:
        screen.blit(pygame.transform.rotate(projectile.arrow_img,i.rotate),i.pos)
        #pygame.draw.rect(screen,(0,0,255),(i.pos[0]+2,i.pos[1]+2,i.hitbox[0],i.hitbox[1]),True)

def draw_fireball():
    for i in projectile.fireball_list:
        screen.blit(pygame.transform.rotate(projectile.fireball_img,i.rotate),i.pos)
        #pygame.draw.rect(screen,(0,0,255),(i.pos[0]+1,i.pos[1]+1,i.hitbox[0],i.hitbox[1]),True)

def draw_bonus():
    for i in enemies.bonus_list:
        screen.blit(enemies.bonus_img,i.pos,(i.sprite*10,0,10,10))
        #pygame.draw.rect(screen,(0,0,255),(i.pos[0],i.pos[1],i.hitbox[0],i.hitbox[1]),True)

def draw_enemy():
    for i in enemies.enemy_list:
        screen.blit(pygame.transform.flip(i.sprite,i.flipped,False),(i.pos[0]-3,i.pos[1]-6))
        #pygame.draw.rect(screen,(255,0,255),(i.pos[0],i.pos[1],i.hitbox[0],i.hitbox[1]),True)

def draw_world():
    for i in range(len(char.world.test_map[char.levelx][char.levely])):
        for j in range(len(char.world.test_map[char.levelx][char.levely][i])):
            screen.blit(char.world.blocks,(j*settings.tile_size,i*settings.tile_size+settings.tile_size*settings.hud_size),(char.world.test_map[char.levelx][char.levely][i][j]*settings.tile_size%30,char.world.test_map[char.levelx][char.levely][i][j]//3*settings.tile_size,settings.tile_size,settings.tile_size))
            #pygame.draw.rect(screen,(255,0,0),char.world.map_collision[i][j],True)

def draw():
    screen.fill((0,0,0))
    draw_world()
    if not char.dead:
        draw_bonus()
        draw_enemy()
        draw_fireball()
        draw_arrow()
        if char.sword_attack:
            char.update_sword()
            draw_weapon()
    else:
        screen.blit(bold_font.render('YOU DIED',False,(255,255,255)),(56,60))
        screen.blit(font.render('press enter to restart',False,(255,255,255)),(21,76))
        screen.blit(font.render('esc to quit',False,(255,255,255)),(2,20))
    draw_char()
    pygame.display.flip()

while True:
    key=pygame.key.get_pressed()
    for event in pygame.event.get():
        if event.type==pygame.QUIT or key[pygame.K_ESCAPE]:
            pygame.quit()
            sys.exit()
    
    if not char.dead:
        char.update()
        projectile.update_arrow()
        projectile.update_fireball()
        collisions.update()
        char.update_anim()
    draw()
    if char.dead:
        char.update_death()
    fps.tick(60)