import pygame
import settings
menu_box=pygame.Rect(0,0,settings.tile_size*settings.world_size[0],settings.tile_size*settings.hud_size)
hearts=pygame.image.load('sprites/Hearts.png')
sword=pygame.image.load('sprites/Sword.png')
arrow=pygame.image.load('sprites/Item_arrow.png')
empty_heart=hearts.subsurface(0,0,16,16)
full_heart=hearts.subsurface(16,0,16,16)
half_heart=hearts.subsurface(32,0,16,16)


menu_color=(24,20,37)
health_pos=(0,0)