import pygame
import settings
import world

arrow_img=pygame.image.load('sprites/Arrow.png')
fireball_img=pygame.image.load('sprites/Fireball.png')

class arrow:
    def __init__(self,pos,dir):
        self.pos=list(pos)
        self.dir=dir
        if dir[1]==0:
            self.rotate=-90*dir[0]
        else:
            self.rotate=90*(dir[1]+1)
        self.hitbox=(6,6)

arrow_list=[]

def add_arrow(pos,dir):
    global arrow_list
    arrow_list.append(arrow((pos[0]+3,pos[1]+6),dir))

def update_arrow():
    global arrow_list
    for i in arrow_list:
        i.pos[0]+=i.dir[0]*2
        i.pos[1]+=i.dir[1]*2
        if i.pos[0]>settings.world_size[0]*settings.tile_size or i.pos[0]<-10 or i.pos[1]>settings.world_size[1]*settings.tile_size+settings.tile_size*settings.hud_size or i.pos[1]<settings.tile_size*settings.hud_size-10:
            arrow_list.remove(i)
            continue
        for j in range(len(world.map_collision)):
            if pygame.Rect(i.pos[0]+2,i.pos[1]+2,i.hitbox[0],i.hitbox[1]).collidelist(world.map_collision[j])!=-1:
                arrow_list.remove(i)
                break



class fireball:
    def __init__(self,pos,dir):
        self.pos=list(pos)
        self.dir=dir
        self.hitbox=(10,10)
        self.rotate=0
        self.rotate_timer=0

fireball_list=[]

def add_fireball(pos,dir):
    global fireball_list
    fireball_list.append(fireball((pos[0]-1,pos[1]-3),dir))

def update_fireball():
    global fireball_list
    for i in fireball_list:
        i.pos[0]+=i.dir[0]
        i.pos[1]+=i.dir[1]

        i.rotate_timer=(i.rotate_timer+1)%5
        if i.rotate_timer==4:
            i.rotate=(i.rotate-90)%360

        if i.pos[0]>settings.world_size[0]*settings.tile_size or i.pos[0]<-10 or i.pos[1]>settings.world_size[1]*settings.tile_size+settings.tile_size*settings.hud_size or i.pos[1]<settings.tile_size*settings.hud_size-10:
            fireball_list.remove(i)
