import pygame
import char, enemies, projectile, settings

def update():
    arrow_hitboxes=[]
    for i in projectile.arrow_list:
            arrow_hitboxes.append(pygame.Rect(i.pos[0]+2,i.pos[1]+2,i.hitbox[0],i.hitbox[1]))
    
    for i in projectile.fireball_list:
        fireball_hitbox=pygame.Rect((i.pos[0]+1,i.pos[1]+1,i.hitbox[0],i.hitbox[1]))
        if char.hitbox.colliderect(fireball_hitbox):
            if not char.hurt:
                char.update_health(1)
    
    for i in enemies.bonus_list:
        bonus_hitbox=pygame.Rect((i.pos[0]+1,i.pos[1]+1,i.hitbox[0],i.hitbox[1]))
        if char.hitbox.colliderect(bonus_hitbox):
            if i.type==0:
                char.update_health(-2)
            else:
                char.arrow_count+=2
            enemies.bonus_list.remove(i)

    for i in range(len(enemies.enemy_list)):
        enemy=enemies.enemy_list[i]
        enemy_hitbox=pygame.Rect(enemies.enemy_list[i].pos[0],enemies.enemy_list[i].pos[1],enemies.enemy_list[i].hitbox[0],enemies.enemy_list[i].hitbox[1])
        
        if (enemy.pos[0]+5)//1<(char.pos[0]+8)//1:
            enemy.move(0,1)
        elif (enemy.pos[0]+5)//1>(char.pos[0]+8)//1:
            enemy.move(0,-1)
        if (enemy.pos[1]+5)//1<(char.pos[1]+12)//1:
            enemy.move(1,1)
        elif (enemy.pos[1]+5)//1>(char.pos[1]+12)//1:
            enemy.move(1,-1)
        
        if abs(enemy.pos[0]-char.pos[0])>abs(enemy.pos[1]-char.pos[1]-8):
            x_axis=True
        else:
            x_axis=False

        if x_axis:
            if enemy.pos[0]-char.pos[0]>0:
                enemy.animation=1
                enemy.flipped=True
            else:
                enemy.animation=1
                enemy.flipped=False
        else:
            if enemy.pos[1]-char.pos[1]-8>0:
                enemy.animation=2
                enemy.flipped=False
            else:
                enemy.animation=0
                enemy.flipped=False
        
        if enemy.can_shoot:
            fireball_dir=((char.pos[0]+8)-(enemy.pos[0]+5),(char.pos[1]+12)-(enemy.pos[1]+5))
            enemy.shoot(settings.normal(fireball_dir))
        
        if char.hitbox.colliderect(enemy_hitbox):
            if not char.hurt:
                char.update_health(1)
        if char.sword_hitbox.colliderect(enemy_hitbox) and char.sword_attack and char.attack_timer>=8 and char.attack_timer<=16:
            if enemy.hurt==0:
                enemy.get_hurt(char.face_direction)
                if enemy.health<=0:
                    enemies.add_bonus(enemy.pos)
                    enemies.enemy_list.pop(i)
                    break
        target_arrow=enemy_hitbox.collidelist(arrow_hitboxes)
        if target_arrow!=-1:
            if enemy.hurt==0:
                enemy.get_hurt(projectile.arrow_list[target_arrow].dir)
                if enemy.health<=0:
                    enemies.add_bonus(enemy.pos)
                    enemies.enemy_list.remove(enemy)
            projectile.arrow_list.remove(projectile.arrow_list[target_arrow])
            break
        
        enemy.animate()