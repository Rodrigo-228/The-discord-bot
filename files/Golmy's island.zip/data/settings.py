from numpy import sqrt
tile_size=10
world_size=(16,10)
hud_size=2

def normal(v):
    c=sqrt(v[0]**2+v[1]**2)
    return(v/c)