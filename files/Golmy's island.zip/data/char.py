import pygame
import char_menu
import projectile
import world
import enemies
import settings

sprite_sheet=pygame.image.load('sprites/Golmy.png')
pos=[60,60]
animation=0 #0=Idle 1=Run 2=Attack
anim_state=0
anim_clock=0
frame=0
flip=False
sprite=sprite_sheet.subsurface((frame*16%80,frame//5*16,16,16))
face_direction=(0,1)
speed=0.6
hitbox=pygame.Rect(pos[0]+5,pos[1]+10,6,6)
max_health=6
health=max_health
invincibility=60
invincibility_frame=0
hurt=False
dead=False

levelx=0
levely=0

#weapons
can_move=True
attack_timer=0
#--sword
sword_attack=False
sword_img=pygame.image.load('sprites/Sword.png')
sword=sword_img
swipe_img=pygame.image.load('sprites/Swipe.png')
swipe=swipe_img
sword_pos=(0,0)
swipe_pos=(0,0)
sword_hitbox=pygame.Rect(0,0,12,12)
#--arrow
arrow_attack=False
arrow_count=2

def update_sword():
    global attack_timer
    global sword_pos
    global sword
    global sword_attack
    global can_move
    global swipe_pos
    global swipe
    global sword_hitbox
    attack_timer+=1
    if attack_timer<8:
        if face_direction==(0,1):
            rotation=-90
            sword_pos=(13,2)
        elif face_direction==(0,-1):
            rotation=90
            sword_pos=(-13,6)
        elif face_direction==(1,0):
            rotation=0
            sword_pos=(0,-10)
        elif face_direction==(-1,0):
            rotation=0
            sword_pos=(0,-10)
    else:
        if face_direction==(0,1):
            rotation=180
            sword_pos=(-3,15)
            swipe_pos=(6,10)
            sword_hitbox=pygame.Rect(pos[0]+2,pos[1]+16,12,12)
        elif face_direction==(0,-1):
            rotation=0
            sword_pos=(3,-7)
            swipe_pos=(-6,-2)
            sword_hitbox=pygame.Rect(pos[0]+2,pos[1]-2,12,12)
        elif face_direction==(1,0):
            rotation=-90
            sword_pos=(13,5)
            swipe_pos=(8,-4)
            sword_hitbox=pygame.Rect(pos[0]+11,pos[1]+7,12,12)
        elif face_direction==(-1,0):
            rotation=90
            sword_pos=(-13,5)
            swipe_pos=(-8,-4)
            sword_hitbox=pygame.Rect(pos[0]-7,pos[1]+7,12,12)

    if face_direction==(-1,0):
        swipe=pygame.transform.flip(swipe_img,True,False)
    else:
        swipe=pygame.transform.rotate(swipe_img,rotation+90)
    sword=pygame.transform.rotate(sword_img,rotation)
    if attack_timer==18:
        sword_attack=False
        can_move=True
        change_animation(0)
    

def launch_arrow():
    global attack_timer
    global can_move
    global arrow_attack
    global arrow_count
    attack_timer+=1
    if attack_timer==8:
        projectile.add_arrow((pos[0],pos[1]+2),face_direction)
        arrow_count-=1
    elif attack_timer==18:
        can_move=True
        arrow_attack=False
        change_animation(0)
    

def load_new_map(level_dir_x,level_dir_y):
    global levelx
    global levely
    global pos
    projectile.arrow_list=[]
    projectile.fireball_list=[]
    enemies.bonus_list=[]
    levelx=(levelx+level_dir_x)%len(world.test_map)
    levely=(levely+level_dir_y)%len(world.test_map[1])
    world.new_collision(levelx,levely)
    enemies.new_enemies(levelx,levely)
    if level_dir_x==1:
        pos[0]=-4
    elif level_dir_x==-1:
        pos[0]=settings.tile_size*settings.world_size[0]-12
    
    if level_dir_y==1:
        pos[1]=-4+settings.tile_size*settings.hud_size
    elif level_dir_y==-1:
        pos[1]=settings.tile_size*settings.world_size[1]-12+settings.tile_size*settings.hud_size

def change_animation(anim):
    global animation
    global anim_state
    global anim_clock
    if animation!=anim:
        anim_clock=0
        anim_state=0
        animation=anim

def move(axis,dir):
    global hitbox
    global pos
    last_pos=pos[axis]
    pos[axis]+=speed*dir
    hitbox=pygame.Rect(pos[0]+5,pos[1]+10,6,6)
    for i in range(len(world.map_collision)):
        if hitbox.collidelist(world.map_collision[i])!=-1:
            pos[axis]=last_pos
            hitbox=pygame.Rect(pos[0]+5,pos[1]+10,6,6)

def update_health(damage):
    global health
    global invincibility_frame
    global hurt
    global dead
    health-=damage
    if health<=0:
        dead=True
    elif damage>0:
        invincibility_frame=invincibility
        hurt=True
    else:
        if health>6:
            health=6

def update_invincibility():
    global invincibility_frame
    global hurt
    invincibility_frame-=1
    if invincibility_frame==0:
        hurt=False

def update():
    global pos
    global face_direction
    global frame
    global animation
    global anim_state
    global anim_clock
    global sprite
    global sword_attack
    global can_move
    global attack_timer
    global arrow_attack
    key=pygame.key.get_pressed()
    keyjp=pygame.key.get_just_pressed()

    #movement
    moving=False
    if hurt:
        update_invincibility()

    if keyjp[pygame.K_z] and can_move:
        sword_attack=True
        can_move=False
        attack_timer=0
        change_animation(2)
    
    elif keyjp[pygame.K_x] and can_move and arrow_count>0:
        arrow_attack=True
        can_move=False
        attack_timer=0
        change_animation(2)
        launch_arrow()

    if arrow_attack:
        launch_arrow()

    if can_move:
        if key[pygame.K_RIGHT] and not key[pygame.K_LEFT]:
            move(0,1)
            change_animation(1)
            face_direction=(1,0)
            moving=True
        elif key[pygame.K_LEFT] and not key[pygame.K_RIGHT]:
            move(0,-1)
            change_animation(1)
            face_direction=(-1,0)
            moving=True
        if key[pygame.K_UP] and not key[pygame.K_DOWN]:
            move(1,-1)
            change_animation(1)
            face_direction=(0,-1)
            moving=True
        elif key[pygame.K_DOWN] and not key[pygame.K_UP]:
            move(1,1)
            change_animation(1)
            face_direction=(0,1)
            moving=True
    
        if not moving:
            change_animation(0)

    if pos[0]>=settings.tile_size*settings.world_size[0]-10:
        load_new_map(1,0)
    elif pos[0]<=-6:
        load_new_map(-1,0)
    
    if pos[1]>=settings.tile_size*settings.world_size[1]-10+settings.tile_size*settings.hud_size:
        load_new_map(0,1)
    elif pos[1]<=-6+settings.tile_size*settings.hud_size:
        load_new_map(0,-1)

def update_anim():
    global animation
    global anim_state
    global anim_clock
    global animation
    global anim_state
    global anim_clock
    global face_direction
    global flip
    global sprite
    if animation==0:
        if face_direction==(0,1):
            frame=0
        elif face_direction==(0,-1):
            frame=10
        else:
            frame=5
    elif animation==1:
        if anim_clock==10:
                anim_clock=0
                anim_state=(anim_state+1)%4
        else:
            anim_clock+=1

        if face_direction==(0,1):
            if anim_state==0:
                frame=1
            elif anim_state==1 or anim_state==3:
                frame=0
            else:
                frame=2
        elif face_direction==(0,-1):
            if anim_state==0:
                frame=11
            elif anim_state==1 or anim_state==3:
                frame=10
            else:
                frame=12
        else:
            if anim_state==0:
                frame=6
            elif anim_state==1 or anim_state==3:
                frame=5
            else:
                frame=7
    elif animation==2:
        if anim_clock==8:
                anim_clock=9
                anim_state=+1
        else:
            anim_clock+=1
        if face_direction==(0,1):
            if anim_state==0:
                frame=3
            else:
                frame=4
        elif face_direction==(0,-1):
            if anim_state==0:
                frame=13
            else:
                frame=14
        else:
            if anim_state==0:
                frame=8
            else:
                frame=9
    
    if face_direction==(-1,0):
        flip=True
    else:
        flip=False
    sprite=sprite_sheet.subsurface((frame*16%80,frame//5*16,16,16))

def update_death():
    global dead
    global health
    global arrow_count
    global pos
    global animation
    global face_direction
    global levelx
    global levely
    global can_move
    global attack_timer
    global sword_attack
    global arrow_attack
    keyjp=pygame.key.get_just_pressed()
    if keyjp[pygame.K_RETURN]:
        dead=False
        health=max_health
        arrow_count=2
        pos=[60,60]
        animation=0
        face_direction=(0,1)
        can_move=True
        attack_timer=0
        sword_attack=False
        arrow_attack=False
        
        projectile.arrow_list=[]
        projectile.fireball_list=[]
        enemies.bonus_list=[]
        levelx=0
        levely=0
        world.new_collision(levelx,levely)
        enemies.new_enemies(levelx,levely)